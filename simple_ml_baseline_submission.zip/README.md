# Simple ML Baseline

## Objective
Prepare a public dataset, split it into training and test sets, compare a trivial baseline with a simple model, and report test accuracy.

## Dataset
This notebook uses the Wisconsin Diagnostic Breast Cancer dataset included in `scikit-learn` (`load_breast_cancer`). It is a public educational dataset of numeric features derived from cell images. The target has two classes: malignant and benign.

## What the notebook does
1. Loads the dataset and immediately creates a stratified 80/20 train/test split.
2. Fits a `DummyClassifier(strategy="most_frequent")` as the trivial baseline.
3. Fits a logistic-regression model with scaling inside a pipeline. The scaler is learned from training data only.
4. Reports baseline and logistic-regression accuracy on the held-out test set.

The main score to report is **Logistic regression test accuracy**. The notebook prints the exact score when run. Do not copy a score into this README without running the notebook and checking its output.

## How to run
### Option A: Google Colab
1. Upload `baseline_model.ipynb` to Google Colab.
2. Run all cells from top to bottom.

### Option B: Local computer
1. Install Python 3.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Start Jupyter:
   ```bash
   jupyter notebook baseline_model.ipynb
   ```
4. Run all cells from top to bottom.

## Reproducibility and decisions
- Test size: 20%.
- `random_state=42` makes the split reproducible.
- `stratify=y` keeps class proportions similar in train and test.
- The test set is not used to fit the model or scaler.
- Accuracy is easy to understand, but it does not capture every kind of classification error.

## Important note
This is a small educational machine-learning example, not a medical diagnostic tool.
